/* ============================================================
   JAURES PREGNON — script.js
   Sécurité JavaScript :
   - mode strict + IIFE (aucune variable globale)
   - anti-clickjacking (frame busting)
   - plus aucun innerHTML : le HTML traduit passe par un
     assainisseur à liste blanche (anti-XSS)
   - valeurs de localStorage validées (liste blanche) + try/catch
   - liens externes forcés en rel="noopener noreferrer"
   - aucun eval / Function / document.write
   ============================================================ */
(function () {
    'use strict';

    // Active les animations uniquement si le JavaScript fonctionne
    document.documentElement.classList.add('js');

    /* ---------- 1. Anti-clickjacking ---------- */
    if (window.top !== window.self) {
        try { window.top.location = window.self.location; }
        catch (e) { document.documentElement.style.display = 'none'; }
    }

    /* ---------- 2. Stockage sécurisé ---------- */
    const SUPPORTED_LANGS = Object.freeze(['fr', 'en']);
    const STORAGE_KEY = 'portfolio-lang';

    function safeGetLang() {
        try {
            const v = window.localStorage.getItem(STORAGE_KEY);
            return SUPPORTED_LANGS.includes(v) ? v : 'fr';
        } catch (e) { return 'fr'; }
    }
    function safeSetLang(lang) {
        if (!SUPPORTED_LANGS.includes(lang)) return;
        try { window.localStorage.setItem(STORAGE_KEY, lang); } catch (e) { /* ignoré */ }
    }

    /* ---------- 3. Assainisseur HTML à liste blanche ---------- */
    const ALLOWED_TAGS = Object.freeze({ STRONG: 1, B: 1, EM: 1, BR: 1, I: 1 });
    const ICON_CLASS_RE = /^(fas|far|fab|fa-[a-z0-9-]+|icon-accent)(\s+(fas|far|fab|fa-[a-z0-9-]+|icon-accent))*$/;

    function sanitizeInto(target, html) {
        const doc = new DOMParser().parseFromString(String(html), 'text/html');
        const fragment = document.createDocumentFragment();

        (function walk(source, dest) {
            source.childNodes.forEach(function (node) {
                if (node.nodeType === Node.TEXT_NODE) {
                    dest.appendChild(document.createTextNode(node.textContent));
                } else if (node.nodeType === Node.ELEMENT_NODE && ALLOWED_TAGS[node.tagName]) {
                    const el = document.createElement(node.tagName.toLowerCase());
                    // seul l'attribut "class" est autorisé, et uniquement sur <i> (icônes)
                    if (node.tagName === 'I') {
                        const cls = node.getAttribute('class') || '';
                        if (ICON_CLASS_RE.test(cls)) el.setAttribute('class', cls);
                        el.setAttribute('aria-hidden', 'true');
                    }
                    walk(node, el);
                    dest.appendChild(el);
                }
                // tout le reste (script, img, a, iframe, attributs on*, etc.) est ignoré
            });
        })(doc.body, fragment);

        target.replaceChildren(fragment);
    }

    /* ---------- 4. Moteur de traduction ---------- */
    const langBtn = document.getElementById('langBtn');
    let currentLang = safeGetLang();

    function updateLanguage(lang) {
        if (!SUPPORTED_LANGS.includes(lang)) lang = 'fr';

        document.querySelectorAll('[data-fr][data-en]').forEach(function (el) {
            const text = el.getAttribute('data-' + lang);
            if (text === null) return;
            if (text.indexOf('<') !== -1) {
                sanitizeInto(el, text);
            } else {
                el.textContent = text;
            }
        });

        document.documentElement.setAttribute('lang', lang);
        if (langBtn) {
            const label = langBtn.querySelector('span');
            if (label) label.textContent = lang === 'fr' ? 'EN' : 'FR';
        }
        safeSetLang(lang);
    }

    if (langBtn) {
        langBtn.addEventListener('click', function () {
            currentLang = currentLang === 'fr' ? 'en' : 'fr';
            updateLanguage(currentLang);
        });
    }

    /* ---------- 5. Liens sécurisés ---------- */
    function hardenLinks() {
        document.querySelectorAll('a[href]').forEach(function (a) {
            const href = a.getAttribute('href') || '';
            // Bloque les schémas dangereux (javascript:, data:, vbscript:)
            if (/^\s*(javascript|data|vbscript):/i.test(href)) {
                a.removeAttribute('href');
                return;
            }
            // Liens http(s) vers un autre domaine
            if (/^https?:\/\//i.test(href)) {
                try {
                    if (new URL(href, location.href).origin !== location.origin) {
                        a.setAttribute('target', '_blank');
                        a.setAttribute('rel', 'noopener noreferrer');
                    }
                } catch (e) { a.removeAttribute('href'); }
            }
        });
    }

    /* ---------- 6. Animation "reveal" ---------- */
    function reveal() {
        const vh = window.innerHeight;
        document.querySelectorAll('.reveal:not(.active)').forEach(function (el) {
            if (el.getBoundingClientRect().top < vh - 100) el.classList.add('active');
        });
    }
    window.addEventListener('scroll', reveal, { passive: true });

    /* ---------- 7. Initialisation + loader ---------- */
    function hideLoader() {
        const loader = document.getElementById('loader');
        if (!loader || loader.classList.contains('hidden')) return;
        loader.classList.add('fade');
        setTimeout(function () { loader.classList.add('hidden'); }, 400);
    }

    function init() {
        updateLanguage(currentLang);
        hardenLinks();
        reveal();
        // Le loader ne dépend plus du téléchargement des images/polices/CDN
        setTimeout(hideLoader, 300);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Filet de sécurité : au pire, on masque le loader après 3 s
    setTimeout(hideLoader, 3000);
    window.addEventListener('load', reveal);
})();